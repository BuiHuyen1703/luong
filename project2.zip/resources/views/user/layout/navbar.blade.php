<nav class="navbar navbar-transparent navbar-absolute">
    <div class="container-fluid">
        <div class="collapse navbar-collapse">
            <ul class="nav navbar-nav navbar-right">
                <li>
                    <a href="{{ route('logout-user') }}">
                        <i class="material-icons">person</i>
                        <span>
                            Đăng xuất</span>
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>
