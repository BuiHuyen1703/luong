
<?php $__env->startSection('title','Chức vụ'); ?>

<?php $__env->startSection('huyen'); ?>
<div class="card">
    <div class="card-header card-header-icon" data-background-color="rose">
        <i class="material-icons">assignment</i>
    </div>
    <div class="card-content">
        <h3 class="card-title">Thông tin chức vụ</h3>
        <div class="table-responsive">
            <h4><a href="<?php echo e(route('jobTitle.create')); ?>">Thêm chức vụ</a></h4>
            <table class="table">
                    <th>Mã chức vụ</th>
                    <th>Tên chức vụ</th>
                    <th></th>
                    <th></th>
                <tbody>
                    <?php $__currentLoopData = $listJob; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jobTitle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                            <td><?php echo e($jobTitle->id_jobTitle); ?></td>
                            <td><?php echo e($jobTitle->name_jobTitle); ?></td>
                            <td><a class="btn btn-sm btn-warning" href="<?php echo e(route('jobTitle.edit', $jobTitle->id_jobTitle)); ?>"><i
                                        class="fa fa-edit"></i> Sửa</a></td>
                            <td>
                                <a class="btn btn-sm btn-danger"href="<?php echo e(route('jobTitle.hide', $jobTitle->id_jobTitle)); ?>">
                                    <i class="fa fa-times"></i>
                                    Ẩn
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\my_project\resources\views/job_title/list.blade.php ENDPATH**/ ?>