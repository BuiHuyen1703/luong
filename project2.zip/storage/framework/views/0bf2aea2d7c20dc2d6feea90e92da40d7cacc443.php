

<?php $__env->startSection('title', 'Trang chủ'); ?>

<?php $__env->startSection('user'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <?php if(Session::exists('success')): ?>
                    <div class="text-center"><?php echo e(Session::get('success')); ?></div>
                <?php endif; ?>
                <form id="RegisterValidation" action="<?php echo e(route('changePaPro', $emp->id_employee)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="card-header card-header-icon" data-background-color="rose">
                        <i class="material-icons">mail_outline</i>
                    </div>
                    <div class="card-content">
                        <h4 class="card-title">Thay đổi mật khẩu</h4>
                        <div class="form-group label-floating">
                            <label class="control-label">
                                Current Password
                                <small>*</small>
                            </label>
                            <input class="form-control" type="password" name="current_password" required="true" />
                            <?php if(Session::exists('error')): ?>
                                <div><?php echo e(Session::get('error')); ?></div>
                            <?php endif; ?>
                        </div>
                        <div class="form-group label-floating">
                            <label class="control-label">
                                New Password
                                <small>*</small>
                            </label>
                            <input class="form-control" name="new_password" id="registerPassword" type="password"
                                required="true" />
                        </div>
                        <div class="form-group label-floating">
                            <label class="control-label">
                                Confirm New Password
                                <small>*</small>
                            </label>
                            <input class="form-control" name="new_password_confirmation" id="registerPasswordConfirmation"
                                type="password" required="true" equalTo="#registerPassword" />
                            <?php if(Session::exists('error1')): ?>
                                <div><?php echo e(Session::get('error1')); ?></div>
                            <?php endif; ?>
                        </div>
                        <div class="form-footer text-center">

                            <button type="submit" class="btn btn-rose btn-fill">Lưu</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project2\resources\views/infor/changPass.blade.php ENDPATH**/ ?>