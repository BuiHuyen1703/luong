
<?php $__env->startSection('huyen'); ?>
    <h1>Sửa level</h1>
    <form action="<?php echo e(route('level.update', $level->id_level)); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field("PUT"); ?>
        Tên <input type="text" value="<?php echo e($level->basic_salary); ?>" name="basic_salary"><br>
        <button>Sửa</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\my_project\resources\views/level/edit.blade.php ENDPATH**/ ?>