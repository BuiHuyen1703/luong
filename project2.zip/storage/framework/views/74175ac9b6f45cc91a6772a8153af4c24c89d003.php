
<?php $__env->startSection('huyen'); ?>
    <h1>Thêm Department</h1>
    <form action="<?php echo e(route('department.store')); ?>" method="post">
        <?php echo csrf_field(); ?>
        tên : <input type="text" name="namePart">
        <input value="1" readonly name="available">
        <button>Thêm</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\my_project\resources\views/department/create.blade.php ENDPATH**/ ?>