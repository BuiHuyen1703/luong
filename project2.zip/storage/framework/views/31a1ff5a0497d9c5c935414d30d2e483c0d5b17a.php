<nav class="navbar navbar-transparent navbar-absolute">
    <div class="container-fluid">
        <div class="collapse navbar-collapse">
            <ul class="nav navbar-nav navbar-right">
                <li>
                    <a href="">
                        <i class="material-icons">person</i>
                        <span>Đăng xuất</span>
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>
<?php /**PATH C:\xampp\htdocs\my_project\resources\views/user/layout/navbar.blade.php ENDPATH**/ ?>