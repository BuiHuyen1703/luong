
<?php $__env->startSection('title', 'Danh sách Admin'); ?>
<?php $__env->startSection('huyen'); ?>

    <div class="card">
        <div class="card-header card-header-icon" data-background-color="rose">
            <i class="material-icons">assignment</i>
        </div>
        <div class="card-content">
            <h3 class="card-title">Thông tin Admin </h3>
            <button>
                <a href="<?php echo e(route('admin.create')); ?>">Thêm Admin</a>
            </button>
            <form action="">
                <input type="search" value="<?php echo e($search); ?>" name="search">
                <button>Tìm</button>
            </form>
            <div class="table-responsive">
                <table class="table">
                    <tr>
                        <th>Họ tên</th>
                        <th>Số điện thoại</th>
                        <th>Email</th>
                        
                        <th>role</th>
                        <th></th>
                        <th></th>
                    </tr>
                    <?php $__currentLoopData = $listAdmin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($admin->name_admin); ?></td>
                            <td><?php echo e($admin->phone_admin); ?></td>
                            <td><?php echo e($admin->email_admin); ?></td>
                            
                            <td><?php echo e($admin->Adminname); ?></td>
                            
                            <td>
                                <a class="btn btn-sm btn-warning" href="<?php echo e(route('admin.edit', $admin->id_admin)); ?>">
                                    <i class="fa fa-edit"></i>
                                    Sửa
                                </a>
                            </td>
                            <td>
                                
                                <form action="<?php echo e(route('admin.destroy', $admin->id_admin)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-sm btn-danger">Xóa</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
                <?php echo e($listAdmin->appends([
        'search' => $search,
    ])->links('')); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project2\resources\views/admin/list.blade.php ENDPATH**/ ?>