
<?php $__env->startSection('title','Cập nhật phòng ban'); ?>

<?php $__env->startSection('huyen'); ?>
    
    <div class="row">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header card-header-icon" data-background-color="rose">
                    <i class="material-icons">mail_outline</i>
                </div>
                <div class="card-content">
                    <h3 class="card-title">Cập nhật phòng ban</h3>
                    <form action="<?php echo e(route('department.update', $dep->id_department)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field("PUT"); ?>
                        <div class="form-group label-floating">
                            <label class="control-label">Tên phòng ban</label>
                            <input type="text" class="form-control" value="<?php echo e($dep->name_department); ?>" name="name_dep">
                        </div>
                        <button type="submit" class="btn btn-fill btn-rose">Cập nhật</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\my_project\resources\views/department/edit.blade.php ENDPATH**/ ?>