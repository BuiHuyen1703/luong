
<?php $__env->startSection('title', 'Nhân viên'); ?>

<?php $__env->startSection('huyen'); ?>
    <div class="card">
        <div class="card-header card-header-icon" data-background-color="rose">
            <i class="material-icons">assignment</i>
        </div>
        <div class="card-content">
            <h3 class="card-title">Thông tin nhân viên</h3>
            <form action="">
                
                <select name="id-dep">
                    <option value="">=====</option>
                    <?php $__currentLoopData = $listDepa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($dep->id_department); ?>" <?php if($dep->id_department == $idDep): ?> selected <?php endif; ?>>
                            <?php echo e($dep->name_department); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <button>Tìm</button>
            </form>
            <div class="table-responsive">
                
                <button><a href="<?php echo e(route('employee.insert-excel')); ?>">Thêm bằng excel</a> <br></button>
                
                <table class="table">
                    <th>Tên nhân viên</th>
                    
                    <th>Chi tiết</th>
                    <th></th>

                    <?php $__currentLoopData = $listEmp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($emp->name_empployee); ?></td>
                            
                            <td><a class="btn btn-sm btn-warning" href="<?php echo e(route('employee.show', $emp->id_employee)); ?>"><i
                                        class="fa fa-edit"></i></a>
                            </td>
                            
                            <td></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>

                </table>
                <?php echo e($listEmp->links('')); ?>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project2\resources\views/employee/list.blade.php ENDPATH**/ ?>