
<?php $__env->startSection('title', 'Trang chủ'); ?>
<?php $__env->startSection('huyen'); ?>
    <div class="card">
        <div class="card-header card-header-icon" data-background-color="green">
            <i class="material-icons">&#xE894;</i>
        </div>
        <div class="card-content">
            <h4 class="card-title">Thống kê doanh số</h4>
            
            <form action="">
                
                <input type="date" name="date">
                <button>Tìm</button>
            </form>


            <div class="table-responsive">
                <form action="">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Tổng lương cơ bản </th>
                                <th><?php echo e($salary); ?></th>
                            </tr>
                            <tr>
                                <th>Tổng lương thực nhận</th>
                                <th><?php echo e($idEmp); ?></th>
                            </tr>
                            <tr>
                                <th>Tổng tiền phạt </th>
                                <th><?php echo e($phat); ?></th>
                            </tr>
                        </thead>
                    </table>
                </form>

            </div>

        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project2\resources\views/thongke.blade.php ENDPATH**/ ?>