<div class="collapse navbar-collapse">
    <ul class="nav navbar-nav navbar-right">
        
        
        <li>
            <a href="<?php echo e(route('logout-admin')); ?>">
                <i class="material-icons">person</i>
                <p>Đăng xuất</p>
            </a>
        </li>
        <li class="separator hidden-lg hidden-md"></li>
    </ul>
    
</div>
<?php /**PATH C:\xampp\htdocs\project2\resources\views/header.blade.php ENDPATH**/ ?>