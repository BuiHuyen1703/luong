
<?php $__env->startSection('title', 'Thêm level'); ?>

<?php $__env->startSection('huyen'); ?>

    <div class="col-md-4">
        <div class="card">
            <div class="card-header card-header-icon" data-background-color="rose">
                <i class="material-icons">library_books</i>
            </div>
            <form action="<?php echo e(route('level.store')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="card-content">
                    <h3 class="card-title">Thêm level</h3>
                    <div class="form-group">
                        <label class="label-control">Level</label>
                        <input type="text" class="form-control datetimepicker" name="name_level" />
                        <label class="label-control">Lương cơ bản</label>
                        <input type="number" class="form-control datetimepicker" name="basic_salary" />
                        <input value="1" readonly name="available" hidden />
                    </div>
                    <button class="btn btn-rose">Thêm</button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project2\resources\views/level/create.blade.php ENDPATH**/ ?>