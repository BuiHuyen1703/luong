<nav class="navbar navbar-transparent navbar-absolute">
    <div class="container-fluid">
        <div class="collapse navbar-collapse">
            <ul class="nav navbar-nav navbar-right">
                <li>
                    <a href="<?php echo e(route('logout-user')); ?>">
                        <i class="material-icons">person</i>
                        <span>
                            Đăng xuất</span>
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>
<?php /**PATH C:\xampp\htdocs\project2\resources\views/user/layout/navbar.blade.php ENDPATH**/ ?>