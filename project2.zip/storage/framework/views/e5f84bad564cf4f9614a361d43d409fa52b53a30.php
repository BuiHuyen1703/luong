


<?php $__env->startSection('huyen'); ?>
    
    <div class="card">
        <div class="card-header card-header-icon" data-background-color="rose">
            <i class="material-icons">assignment</i>
        </div>
        <div class="card-content">
            <h3 class="card-title">Thông tin các đơn nghỉ</h3>
            <div class="table-responsive">
                <table class="table">
                    <th>Mã đơn</th>
                    <th><?php echo e($legal->id_legal); ?></th>
                    <tr>
                        <th>Tên nhân viên</th>
                        <td><?php echo e($legal->name_empployee); ?></td>
                    </tr>
                    <tr>
                        <th>Lý do nghỉ</th>
                        <td><?php echo e($legal->reason); ?></td>
                    </tr>
                    <tr>
                        <th>Ngày bắt đầu</th>
                        <td><?php echo e($legal->strat_time_off); ?></td>
                    </tr>
                    <tr>
                        <th>Ngày kết thúc</th>
                        <td><?php echo e($legal->end_time_off); ?></td>
                    </tr>
                    <tr>
                        <th>Ghi chú</th>
                        <td><?php echo e($legal->note); ?></td>
                    </tr>
                    <tr>
                        <th>Tình trạng</th>
                        <td><?php echo e($legal->NameApprove); ?></td>
                    </tr>
                    
                    
                    <tr>
                        <td>
                            <a class="btn btn-xs btn-success" href="<?php echo e(route('legalOff.haha', $legal->id_legal)); ?>">
                                <i class="material-icons">check</i> duyệt
                            </a>
                            <a class="btn btn-xs btn-danger" href="<?php echo e(route('legalOff.hihi', $legal->id_legal)); ?>">
                                <i class="material-icons">close</i> từ chối
                                <a>
                        </td>
                    </tr>
                    
                    

                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project2\resources\views/legal_off/show.blade.php ENDPATH**/ ?>