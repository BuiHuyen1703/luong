
<?php $__env->startSection('title', 'Phòng ban'); ?>

<?php $__env->startSection('huyen'); ?>
    
    <div class="card">
        <div class="card-header card-header-icon" data-background-color="rose">
            <i class="material-icons">assignment</i>
        </div>
        <div class="card-content">
            <h3 class="card-title">Thông tin phòng ban</h3>
            <div class="table-responsive">
                <button><a href="<?php echo e(route('department.create')); ?>">Thêm phòng ban</a></button>
                <form action="">
                    <table class="table">
                        <th>Mã phòng ban</th>
                        <th>Tên phòng ban</th>
                        <th></th>
                        <th></th>
                        <tbody>
                            <?php $__currentLoopData = $listPart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $depart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($depart->id_department); ?></td>
                                    <td><?php echo e($depart->name_department); ?></td>
                                    <td>
                                        <a class="btn btn-sm btn-warning"
                                            href="<?php echo e(route('department.edit', $depart->id_department)); ?>"><i
                                                class="fa fa-edit"></i> Sửa</a>
                                    </td>
                                    <td>
                                        <a class="btn btn-sm btn-danger"
                                            href="<?php echo e(route('department.hide', $depart->id_department)); ?>"><i
                                                class="fa fa-times"></i> Ẩn</a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </form>
            </div>
        </div>
    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project2\resources\views/department/list.blade.php ENDPATH**/ ?>