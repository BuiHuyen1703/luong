
<?php $__env->startSection('title', 'Đơn xin nghỉ'); ?>

<?php $__env->startSection('huyen'); ?>
    
    <div class="card">
        <div class="card-header card-header-icon" data-background-color="rose">
            <i class="material-icons">assignment</i>
        </div>
        <div class="card-content">
            <h3 class="card-title">Thông tin các đơn nghỉ</h3>
            <div class="table-responsive">
                <table class="table">
                    <th>Mã đơn</th>
                    <th>Tên nhân viên</th>
                    
                    <th>Tình trạng</th>
                    <th></th>
                    <th></th>
                    <tbody>
                        <?php $__currentLoopData = $listLegal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $legal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($legal->id_legal); ?></td>
                                <td><?php echo e($legal->name_empployee); ?></td>
                                
                                
                                
                                
                                <td><?php echo e($legal->NameApprove); ?></td>

                                
                                <td>
                                <td><a class="btn btn-sm btn-watch"
                                        href="<?php echo e(route('legalOff.show', $legal->id_legal)); ?>"><i
                                            class="fa fa-edit"></i></a>
                                </td>
                                
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <?php echo e($listLegal->links('')); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\my_project\resources\views/legal_off/list.blade.php ENDPATH**/ ?>