<div class="collapse navbar-collapse">
    <ul class="nav navbar-nav navbar-right">
        
        
        <li>
            <a href="<?php echo e(route('logout')); ?>">
                <i class="material-icons">person</i>
                <p>Đăng xuất</p>
            </a>
        </li>
        <li class="separator hidden-lg hidden-md"></li>
    </ul>
    <form class="navbar-form navbar-right" role="search">
        <div class="form-group form-search is-empty">
            <input type="text" class="form-control" placeholder=" Search ">
            <span class="material-input"></span>
        </div>
        <button type="submit" class="btn btn-white btn-round btn-just-icon">
            <i class="material-icons">search</i>
            <div class="ripple-container"></div>
        </button>
    </form>
</div>
<?php /**PATH C:\xampp\htdocs\my_project\resources\views/header.blade.php ENDPATH**/ ?>