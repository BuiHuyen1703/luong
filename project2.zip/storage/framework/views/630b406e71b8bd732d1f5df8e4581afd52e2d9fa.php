
<?php $__env->startSection('huyen'); ?>

    <div class="card">
        <h1>Thêm bằng excel</h1>
        <form action="<?php echo e(route('employee.insert-excel-process')); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <input type="file" name="excel"
                accept=".csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel" />
            <button>Thêm</button>
        </form>
        
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project2\resources\views/employee/insert-excel.blade.php ENDPATH**/ ?>