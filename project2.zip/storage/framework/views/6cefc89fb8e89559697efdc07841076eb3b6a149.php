<table class="table">
    <thead>
        <tr>
            <th>Mã chấm công</th>
            <th>Mã nhân viên</th>
            <th>Tên nhân viên</th>
            <th>Checkin</th>
            <th>Checkout</th>
            <th>date</th>
            <th>Phat</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $listTime; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $time): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($time->id_timekeeping); ?></td>
                <td><?php echo e($time->id_employee); ?></td>
                <td><?php echo e($time->name_empployee); ?></td>
                <td><?php echo e($time->checkin); ?></td>
                <td><?php echo e($time->checkout); ?></td>
                <td><?php echo e($time->date); ?></td>
                <td><?php echo e($time->phat); ?></td>
                
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>


<table class="table">


    <tr>
        <th>Mã</th>
        <th>Mã nhân viên</th>
        <th>Tên nhân viên</th>
        <th>Lương cơ bản</th>
        <th>Chức vụ</th>
        <th>Lương thực nhận</th>
        
    </tr>

    <tbody>
        
        <?php
            $i = 1;
        ?>
        <?php $__currentLoopData = $idEmp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $salary): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($i++); ?></td>
                <td><?php echo e($salary['id_employee']); ?></td>
                <td><?php echo e($salary['ten_nv']); ?></td>
                <td><?php echo e($salary['salary_basic']); ?></td>
                <td><?php echo e($salary['job_title']); ?></td>
                <td><?php echo e($salary['salary']); ?></td>
                
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        


        <form action="">
            <table class="table">
                <thead>
                    <tr>
                        <th>Tổng lương cơ bản </th>
                        <th><?php echo e($salary); ?></th>
                    </tr>
                    <tr>
                        <th>Tổng lương thực nhận</th>
                        <th><?php echo e($idEmp); ?></th>
                    </tr>
                    <tr>
                        <th>Tổng tiền phạt </th>
                        <th><?php echo e($phat); ?></th>
                    </tr>
                </thead>
            </table>
        </form>
    </tbody>


</table>
<?php /**PATH C:\xampp\htdocs\project2\resources\views/timekeeping/export.blade.php ENDPATH**/ ?>