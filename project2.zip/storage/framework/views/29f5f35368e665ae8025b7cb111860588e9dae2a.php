
<?php $__env->startSection('huyen'); ?>
    <h1>Sửa ngày nghỉ</h1>
    <form action="<?php echo e(route('holiday.update', $holi->id_holiday)); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field("PUT"); ?>
        tên : <input type="text" value="<?php echo e($holi->name_holiday); ?>" name="name_holiday">
        ngày: <input type="date" value="<?php echo e($holi->date_holiday); ?>" name="date_holiday">
        <button>Sửa</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project2\resources\views/holiday/edit.blade.php ENDPATH**/ ?>