
<?php $__env->startSection('huyen'); ?>
    <h1>Thông tin chi tiết nè</h1>
    <table>
        <tr>
            <td><?php echo e($employee->name_empployee); ?></td>
        </tr>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\my_project\resources\views/employee/show-detail-employee.blade.php ENDPATH**/ ?>