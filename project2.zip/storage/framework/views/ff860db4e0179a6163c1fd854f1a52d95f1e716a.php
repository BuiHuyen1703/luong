
<?php $__env->startSection('title', 'Bảng chấm công'); ?>

<?php $__env->startSection('huyen'); ?>
    <div class="card">
        <div class="card-header card-header-icon" data-background-color="rose">
            <i class="material-icons">assignment</i>
        </div>
        <div class="card-content">
            <h3 class="card-title">Thông tin chấm công</h3>
            <button><a href="<?php echo e(route('check-all')); ?>">check all</a></button>
            
            <form action="<?php echo e(route('export')); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <div class="row">
                    <div class="col-md-2">
                        <div class="form-group">
                            <select name="year" id="" class="selectpicker">
                                <option value="" disabled selected>chọn năm</option>
                                <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($year->value); ?>"><?php echo e($year->value); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-group">
                            <select name="month[]" id="month" multiple class="selectpicker">
                                <option disabled>chọn tháng</option>
                                <option value="">tất cả các tháng</option>
                                <?php for($i = 1; $i <= 12; $i++): ?>
                                    <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                                <?php endfor; ?>
                            </select>
                            <?php $__errorArgs = ['month'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
                <input type="submit" value="Xuất chấm công">
            </form>
            
            <div class="table-responsive">
                <table class="table">
                    <th>Mã chấm công</th>
                    <th>Mã nhân viên</th>
                    <th>Tên nhân viên</th>
                    <th>Checkin</th>
                    
                    <th>date</th>
                    <th>Phat</th>
                    <tbody>
                        <?php $__currentLoopData = $listTime; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $time): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($time->id_timekeeping); ?></td>
                                <td><?php echo e($time->id_employee); ?></td>
                                <td><?php echo e($time->name_empployee); ?></td>
                                <td><?php echo e($time->checkin); ?></td>
                                
                                <td><?php echo e($time->date); ?></td>
                                <td><?php echo e($time->phat); ?></td>

                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <?php echo e($listTime->links('')); ?>


<?php $__env->stopSection(); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"
integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ=="
crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script>
    $(function() {
        $('#month').find('option:disabled').prop('selected', true);
        $('#month').selectpicker('refresh');
    });
</script>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project2\resources\views/timekeeping/list.blade.php ENDPATH**/ ?>