

<?php $__env->startSection('title', 'Trang chủ'); ?>

<?php $__env->startSection('user'); ?>
    <?php use Carbon\Carbon; ?>
    <div class="row">
        
        
        

        <div class="col-md-4">
            <div class="card">
                <div class="card-header card-header-icon" data-background-color="purple">
                    <i class="material-icons">today</i>
                </div>
                <?php if(Session::exists('error')): ?>
                    <div class="text-center"><?php echo e(Session::get('error')); ?></div>
                <?php endif; ?>
                <form action="<?php echo e(route('timekeeping.store')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="card-content">
                        <h3 class="card-title">Check in</h3>
                        <div class="form-group">
                            <input type="hidden" name="id_employee" value="<?php if(session('user')): ?> <?php echo e(session('user')->id_employee); ?> <?php endif; ?> ">
                            <label class="label-control">Ngày/Giờ check in</label>
                            <input type="text" name="date" value="<?php echo e(Carbon::now('Asia/Ho_Chi_Minh')->toDateString()); ?>">
                            <input type="text" class="form-control datetimepicker"
                                value="<?php echo e(Carbon::now('Asia/Ho_Chi_Minh')->toTimeString()); ?>" name="checkin" />
                            <input type="hidden" name="available" value="1">
                        </div>
                        <button class="btn btn-primary">Check in</button>
                    </div>
                </form>
            </div>
        </div>
        
        
        
        <div class="col-md-4">
            <div class="card">
                <div class="card-header card-header-icon" data-background-color="red">
                    <i class="material-icons">today</i>
                </div>
                <form action="<?php echo e(route('timekeeping.store')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="card-content">
                        <h3 class="card-title">Check out</h3>
                        <div class="form-group">
                            

                            <input type="hidden" name="id_employee" value="<?php if(session('user')): ?> <?php echo e(session('user')->id_employee); ?> <?php endif; ?> ">
                            <label class="label-control">Ngày/Giờ check out</label>
                            <input type="text" name="date" value="<?php echo e(Carbon::now('Asia/Ho_Chi_Minh')->toDateString()); ?>">
                            <input type="hidden" name="available" value="1">
                            <input type="text" class="form-control datetimepicker"
                                value="<?php echo e(Carbon::now('Asia/Ho_Chi_Minh')->toTimeString()); ?>" name="checkout" />
                        </div>
                        <button class="btn btn-danger">Check out</button>
                    </div>
                </form>
            </div>
        </div>
        
        


    </div>

    <div class="row">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header card-header-icon" data-background-color="purple">
                    <i class="material-icons">mail_outline</i>
                </div>
                <div class="card-content">
                    <h3 class="card-title">Đơn xin nghỉ</h3>
                    <form method="post" action="<?php echo e(route('legalOff.store')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-group label-floating">
                            
                            <label class="control-label">Tên </label>
                            <input type="hidden" name="name_emp" value="<?php if(session('user')): ?> <?php echo e(session('user')->id_admin ?? session('user')->id_employee); ?> <?php endif; ?> ">
                            <input class=" form-control" name="" value="<?php if(session('user')): ?> <?php echo e(session('user')->name_admin ?? session('user')->name_empployee); ?> <?php endif; ?> ">
                        </div>



                        <div class=" form-group label-floating ">
                            <label class=" control-label">Lý do</label>
                            <input type="text" class="form-control" name="reason">
                        </div>
                        <div class="form-group label-floating">
                            <label class="control-label">Ghi chú</label>
                            <input type="text" class="form-control" name="note">
                        </div>
                        <div class="form-group label-floating">
                            <label>Nghỉ từ ngày</label>
                            <input type="date" class="form-control timepicker" name="start_time_off" />
                        </div>
                        <div class="form-group label-floating">
                            <label>Đến hết ngày ngày</label>
                            <input type="date" class="form-control datepicker" name="end_time_off" />
                        </div>
                        
                        <button type="submit" class="btn btn-fill btn-primary">Gửi</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project2\resources\views/user/index.blade.php ENDPATH**/ ?>