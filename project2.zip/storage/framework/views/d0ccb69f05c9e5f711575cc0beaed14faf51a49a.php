
<?php $__env->startSection('title', 'Cập nhật thông tin nhân viên'); ?>
<?php $__env->startSection('huyen'); ?>
    <h1>Sửa thông tin nhân viên </h1>
    <form action="<?php echo e(route('employee.update', $employee->id_employee)); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field("PUT"); ?>
        Tên <input type="text" value="<?php echo e($employee->name_empployee); ?>" name="name_emp"> <br>
        
        Giới tính :
        <input type="radio" name="gender" value="1" <?php if($employee->gender == 1): ?> checked <?php endif; ?>>Nữ
        <input type="radio" name="gender" value="0" <?php if($employee->gender == 0): ?> checked <?php endif; ?>>Nam<br>
        Ngày sinh <input type="text" value="<?php echo e($employee->dateOfBirth); ?>" name="dateOfBirth"><br>
        Sđt <input type="text" value="<?php echo e($employee->phoneNumber); ?>" name="phone"><br>
        Email <input type="email" value="<?php echo e($employee->email); ?>" name="email"><br>
        Địa chỉ <input type="text" value="<?php echo e($employee->address); ?>" name="address"><br>
        level <input type="text" value="<?php echo e($employee->level); ?>" name="level"><br>
        Phòng ban <select name="id_department">
            <?php $__currentLoopData = $listDep; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($dep->id_department); ?>" <?php if($employee->id_department == $dep->id_department): ?> selected <?php endif; ?>>
                    <?php echo e($dep->name_department); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select><br>
        Chức vụ :
        <select name="id_jobTitle">
            <?php $__currentLoopData = $listJob; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($job->id_jobTitle); ?>" <?php if($employee->id_jobTitle == $job->id_jobTitle): ?> selected <?php endif; ?>>
                    <?php echo e($job->name_jobTitle); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select><br>

        <button onclick="myFunction()">Sửa</button>
    </form>
<?php $__env->stopSection(); ?>
<script>
    function myFunction() {
        alert("Sửa thành công");
    }
</script>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project2\resources\views/employee/edit.blade.php ENDPATH**/ ?>