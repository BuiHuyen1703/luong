
<?php $__env->startSection('title','Bảng chấm công'); ?>

<?php $__env->startSection('huyen'); ?>
    <div class="card">
        <div class="card-header card-header-icon" data-background-color="rose">
            <i class="material-icons">assignment</i>
        </div>
        <div class="card-content">
            <h3 class="card-title">Thông tin chấm công</h3>
            <div class="table-responsive">
                <table class="table">
                    <thead class="text-primary">
                        <tr></tr>
                        <th>Mã chấm công</th>
                        <th>Mã nhân viên</th>
                        <th>Tên nhân viên</th>
                        <th>Checkin</th>
                        <th>Checkout</th>
                        <th></th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $listTime; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $time): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($time->id_timekeeping); ?></td>
                                <td><?php echo e($time->id_employee); ?></td>
                                <td><?php echo e($time->name_empployee); ?></td>
                                <td><?php echo e($time->checkin); ?></td>
                                <td><?php echo e($time->checkout); ?></td>
                                <td>
                                    <a class="btn btn-sm btn-warning"
                                        href="<?php echo e(route('timekeeping.hide', $time->id_timekeeping)); ?>">
                                        <i class="fa fa-times"></i>Ẩn
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <?php echo e($listTime->links('')); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\my_project\resources\views/timekeeping/list.blade.php ENDPATH**/ ?>