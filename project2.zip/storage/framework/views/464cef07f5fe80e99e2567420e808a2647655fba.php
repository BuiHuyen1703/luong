 
 <?php $__env->startSection('title', 'Thông tin nhân viên'); ?>
 <?php $__env->startSection('huyen'); ?>

     <table class="table">
         <tr>
             <td><a class="btn btn-sm btn-warning" href="<?php echo e(route('employee.edit', $employee->id_employee)); ?>"><i
                         class="fa fa-edit"></i>Sửa</a>
             </td>
             <td><a class="btn btn-sm btn-warning" href="<?php echo e(route('employee.hide', $employee->id_employee)); ?>">
                     <i class="fa fa-times"></i>Ẩn
                 </a>
             </td>
         </tr>
         <tr>
             <th>Tên</th>
             <td><?php echo e($employee->name_empployee); ?></td>
         </tr>
         <tr>
             <th>Ngày Sinh</th>
             <td><?php echo e($employee->dateOfBirth); ?></td>
         </tr>
         <tr>
             <th>Giới tính</th>
             <td><?php echo e($employee->NameGender); ?></td>
         </tr>
         <tr>
             <th>Sđt</th>
             <td><?php echo e($employee->phoneNumber); ?></td>
         </tr>
         <tr>
             <th>Địa chỉ</th>
             <td><?php echo e($employee->address); ?></td>
         </tr>
         
         <tr>
             <th>Email</th>
             <td><?php echo e($employee->email); ?></td>
         </tr>
         
         
         <tr>
             <th>Level</th>
             <td><?php echo e($employee->level); ?></td>
         </tr>
         <tr>
             <th>Phòng ban</th>
             <td><?php echo e($employee->name_department); ?></td>
         </tr>
         <tr>
             <th>Chức vụ</th>
             <td><?php echo e($employee->name_jobTitle); ?></td>
         </tr>
     </table>
 <?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project2\resources\views/employee/show.blade.php ENDPATH**/ ?>