
<?php $__env->startSection('title', 'Thêm tài khoản Admin'); ?>
<?php $__env->startSection('huyen'); ?>
    

    <div class="card">
        <div class="card-header card-header-icon" data-background-color="rose">
            <i class="material-icons">contacts</i>
        </div>
        <div class="card-content">
            <h4 class="card-title">Thêm Admin</h4>
            <form action="<?php echo e(route('admin.store')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="form-group label-floating is-empty">
                    <label>Tên Admin</label>
                    <input type="text" class="form-control" name="name_admin">
                    <span class="material-input"></span>
                </div>
                <div class="form-group label-floating is-empty">
                    <label>Số điện thoại</label>
                    <input type="text" class="form-control" name="phone_admin">
                    <span class="material-input"></span>
                </div>
                <div class="form-group label-floating is-empty">
                    <label>Email</label>
                    <input type="email" class="form-control" name="email_admin">
                    <span class="material-input"></span>
                </div>
                <div class="form-group label-floating is-empty">
                    <label>Password</label>
                    <input type="password" class="form-control" name="pass_admin">
                    <span class="material-input"></span>
                </div>
                <div class="form-group label-floating is-empty">
                    <label>Role</label>
                    <input type="text" class="form-control" name="role_admin">
                    <span class="material-input"></span>
                </div>
                <input value="1" readonly name="available" hidden>
                
                <button type="submit" class="btn btn-fill btn-rose">Thêm</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\my_project\resources\views/admin/create.blade.php ENDPATH**/ ?>