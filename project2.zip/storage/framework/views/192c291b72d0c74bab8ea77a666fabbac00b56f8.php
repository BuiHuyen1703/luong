
<?php $__env->startSection('title', 'Nhân viên'); ?>

<?php $__env->startSection('huyen'); ?>
    <div class="card">
        <div class="card-header card-header-icon" data-background-color="rose">
            <i class="material-icons">assignment</i>
        </div>
        <div class="card-content">
            <h3 class="card-title">Thông tin nhân viên</h3>
            <form action="">
                <input type="search" value="<?php echo e($search); ?>" name="search">
                <button>Tìm</button>
            </form>
            <div class="table-responsive">
                
                <a href="<?php echo e(route('employee.insert-excel')); ?>">Thêm bằng excel</a> <br>
                <a href="">Thêm nhân viên</a>

                <table class="table">
                    <thead class="text-primary">
                        <th>Tên nhân viên</th>
                        <th>Trạng thái</th>
                        <th>Chi tiết</th>
                        <th></th>
                    </thead>
                    <?php $__currentLoopData = $listEmp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>

                            <td><?php echo e($emp->name_empployee); ?></td>
                            <td><?php echo e($emp->NameStatus); ?></td>
                            <td><a class="btn btn-sm btn-watch" href="<?php echo e(route('employee.show', $emp->id_employee)); ?>"><i
                                        class="fa fa-edit"></i></a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php echo e($listEmp->appends(['search' => $search])->links('')); ?>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\my_project\resources\views/employee/list.blade.php ENDPATH**/ ?>