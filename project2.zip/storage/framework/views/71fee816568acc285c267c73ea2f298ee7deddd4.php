
<?php $__env->startSection('title', 'Cập nhật thông tin nhân viên'); ?>
<?php $__env->startSection('huyen'); ?>
    <h1>Sửa thông tin nhân viên </h1>
    <form action="<?php echo e(route('employee.update', $employee->id_employee)); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field("PUT"); ?>
        Tên <input type="text" value="<?php echo e($employee->name_empployee); ?>" name="name"> <br>
        Lương 1 giờ <input type="text" value="<?php echo e($employee->salaryPerHour); ?>" name="salaryperhouse"><br>

        <button>Sửa</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\my_project\resources\views/employee/edit.blade.php ENDPATH**/ ?>