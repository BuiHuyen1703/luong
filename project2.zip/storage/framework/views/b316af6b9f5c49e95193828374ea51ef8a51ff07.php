<div class="wrapper">
    <div class="sidebar" data-active-color="rose" data-background-color="black"
        data-image="../../assets/img/sidebar-1.jpg">
        <!--
    Tip 1: You can change the color of active element of the sidebar using: data-active-color="purple | blue | green | orange | red | rose"
    Tip 2: you can also add an image using data-image tag
    Tip 3: you can change the color of the sidebar with data-background-color="white | black"
-->
        
        <div class="sidebar-wrapper">
            <div class="user">
                <div class="photo">
                    <img src="<?php echo e(Avatar::create(session('admin')->name_admin)->toBase64()); ?>" />s
                </div>
                <div class="info">
                    <a data-toggle="collapse" href="#collapseExample" class="collapsed">
                        <span>
                            
                            <?php if(session()->exists('admin')): ?>
                                <span class="text-center">
                                    <?php echo e(session('admin')->name_admin); ?>

                                </span>
                            <?php endif; ?>
                        </span>
                    </a>
                </div>
            </div>
            <ul class="nav">
                
                <li>
                    <a href="<?php echo e(route('statistics.create')); ?>">
                        <i class="material-icons">device_hub</i>
                        <p> Thống kê </p>
                    </a>
                </li>
                <li class="<?php echo e(Request::is('jobTitle') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('jobTitle.index')); ?>">
                        <i class="material-icons">event_seat</i>
                        <p> Chức vụ</p>
                    </a>
                </li>
                <li class="<?php echo e(Request::is('employee') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('employee.index')); ?>">
                        <i class="material-icons">portrait</i>
                        <p> Nhân viên</p>
                    </a>
                </li>
                <li class="<?php echo e(Request::is('legalOff') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('legalOff.index')); ?>">
                        <i class="material-icons">content_paste</i>
                        <p> Đơn xin nghỉ </p>
                    </a>
                </li>
                <li class="<?php echo e(Request::is('timekeeping') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('timekeeping.index')); ?>">
                        <i class="material-icons">timer</i>
                        <p> Bảng chấm công</p>
                    </a>

                </li>
                <li class="<?php echo e(Request::is('department') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('department.index')); ?>">
                        <i class="material-icons">sort</i>
                        <p> Phòng ban</p>
                    </a>
                </li>
                <li class="<?php echo e(Request::is('level') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('level.index')); ?>">
                        <i class="material-icons">sort</i>
                        <p> Level</p>
                    </a>
                </li>
                <?php if(session('admin')->role == 0): ?>
                    <li class="<?php echo e(Request::is('admin') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('admin.index')); ?>">
                            <i class="material-icons">assignment_ind</i>
                            <p> Kế toán </p>
                        </a>
                    </li>

                <?php endif; ?>

                <li class="<?php echo e(Request::is('salary') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('salary.index')); ?>">
                        <i class="material-icons">monetization_on</i>
                        <p> Lương </p>
                    </a>
                </li>

                <li class="<?php echo e(Request::is('holiday') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('holiday.index')); ?>">
                        <i class="material-icons">date_range</i>
                        <p> Nghỉ lễ </p>
                    </a>
                </li>
                <li class="<?php echo e(Request::is('calendal') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('calender')); ?>">
                        <i class="material-icons">date_range</i>
                        <p> Calender </p>
                    </a>
                </li>
            </ul>
        </div>
    </div>
<?php /**PATH C:\xampp\htdocs\project2\resources\views/sidebar.blade.php ENDPATH**/ ?>