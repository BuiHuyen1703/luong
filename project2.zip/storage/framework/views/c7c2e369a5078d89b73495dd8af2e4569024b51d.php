
<?php $__env->startSection('huyen'); ?>
    <?php use Carbon\Carbon; ?>
    <form action="<?php echo e(route('holiday.store')); ?>" method="post">
        <?php echo csrf_field(); ?>

        tên: <input type="text" name="name_holiday">
        ngay: <input type="date" name="date_holiday">
        <button>Thêm</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project2\resources\views/holiday/create.blade.php ENDPATH**/ ?>