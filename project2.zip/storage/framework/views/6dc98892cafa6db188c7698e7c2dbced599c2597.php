
<?php $__env->startSection('title', 'Salary'); ?>

<?php $__env->startSection('huyen'); ?>
    <div class="card">
        <div class="card-header card-header-icon" data-background-color="rose">
            <i class="material-icons">assignment</i>
        </div>
        <div class="card-content">
            <h3 class="card-title">Thông tin bảng lương</h3>
            <form action="<?php echo e(route('salary.luong')); ?>" method="get">
                <div>
                    <input type="date" name="date">

                    <button><i class="fa fa-edit">lương</i></button>
                </div>
            </form>
            <div class="table-responsive">
                <table class="table">
                    <th>Tên nhân viên</th>
                    <th>Từ ngày</th>
                    <th>Đến ngày</th>
                    <th>Level</th>
                    <th>Chức vụ</th>
                    <th>Lương</th>

                    <th></th>
                    <tbody>
                        <?php $__currentLoopData = $listSalary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $salary): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($salary->name_empployee); ?></td>
                                <td><?php echo e($salary->fromdate); ?></td>
                                <td><?php echo e($salary->todate); ?></td>
                                <td><?php echo e($salary->id_level); ?></td>
                                <td><?php echo e($salary->name_jobTitle); ?></td>
                                <td><?php echo e($salary->salary); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project2\resources\views/salary/list.blade.php ENDPATH**/ ?>