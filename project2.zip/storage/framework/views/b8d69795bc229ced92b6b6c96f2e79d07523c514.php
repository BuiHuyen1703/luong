
<?php $__env->startSection('title', 'Trang chủ'); ?>
<?php $__env->startSection('huyen'); ?>

    <div class="card">
        <div class="card-header card-header-icon" data-background-color="green">
            <i class="material-icons">&#xE894;</i>
        </div>
        <div class="card-content">
            <h4 class="card-title">Thống kê</h4>
            <h1>Thống kê tháng <?php echo e($date); ?></h1>
            
            <form action="<?php echo e(route('statistics.index')); ?>">

                
                <input type="date" name="date" value="<?php echo e($date); ?>">
                <select name="id-dep">
                    <option value="0">=====</option>
                    <?php $__currentLoopData = $listDep; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($dep->id_department); ?>" <?php if($dep->id_department == $idDep): ?> selected <?php endif; ?>>
                            <?php echo e($dep->name_department); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

                <button>Tìm</button>
                <input type="submit" value="Xuất chấm công">

            </form>
            

            <div class="table-responsive">
                <form action="">
                    <table class="table">


                        <tr>
                            <th>Mã</th>
                            <th>Mã nhân viên</th>
                            <th>Tên nhân viên</th>
                            <th>Lương cơ bản</th>
                            <th>Chức vụ</th>
                            <th>Lương thực nhận</th>
                            <th>Phạt</th>
                        </tr>

                        <tbody>
                            
                            
                            <?php
                                $i = 1;
                            ?>
                            <?php $__currentLoopData = $idEmp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $salary): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($i++); ?></td>
                                    <td><?php echo e($salary['id_employee']); ?></td>
                                    <td><?php echo e($salary['ten_nv']); ?></td>
                                    <td><?php echo e($salary['salary_basic']); ?></td>
                                    <td><?php echo e($salary['job_title']); ?></td>
                                    <td><?php echo e($salary['salary']); ?></td>
                                    <td><?php echo e($salary['phat']); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </tbody>


                    </table>
                </form>

            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project2\resources\views/index.blade.php ENDPATH**/ ?>