
<?php $__env->startSection('huyen'); ?>
    <div class="card">
        <div class="card-header card-header-icon" data-background-color="rose">
            <i class="material-icons">assignment</i>
        </div>
        <div class="card-content">
            <h3 class="card-title">Thông tin ngày nghỉ lễ</h3>
            <div class="table-responsive">
                <button><a href="<?php echo e(route('holiday.create')); ?>">Thêm ngay nghỉ</a></button>
                <table class="table">
                    <tr>
                        <th>Tên</th>
                        <th>Ngày</th>
                        <th></th>
                    </tr>
                    <?php $__currentLoopData = $listHoliday; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $holi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($holi->name_holiday); ?></td>
                            <td><?php echo e($holi->date_holiday); ?></td>
                            
                            <td>
                                <form action="<?php echo e(route('holiday.destroy', $holi->id_holiday)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-sm btn-danger" onclick="myFunction()">Xóa</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<script>
    function myFunction() {
        alert("Xoá thành công!!!");
    }
</script>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project2\resources\views/holiday/list.blade.php ENDPATH**/ ?>