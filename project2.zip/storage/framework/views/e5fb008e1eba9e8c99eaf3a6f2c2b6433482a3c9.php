
<?php $__env->startSection('title','Cập nhật chức vụ'); ?>

<?php $__env->startSection('huyen'); ?>
    <div class="col-md-4">
        <div class="card">
            <div class="card-header card-header-icon" data-background-color="rose">
                <i class="material-icons">library_books</i>
            </div>
            <form action="<?php echo e(route('jobTitle.update', $job->id_jobTitle)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field("PUT"); ?>
                <div class="card-content">
                    <h4 class="card-title">Câp nhật thông tin chức vụ</h4>
                    <div class="form-group">
                        <label class="label-control">Tên chức vụ</label>
                        <input type="text" value="<?php echo e($job->name_jobTitle); ?>" name="nameJob"/>
                    </div>
                    <button class="btn btn-rose">Cập nhật</button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project2\resources\views/job_title/edit.blade.php ENDPATH**/ ?>